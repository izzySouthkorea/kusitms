package com.example.register_ku;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class real_main extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}
